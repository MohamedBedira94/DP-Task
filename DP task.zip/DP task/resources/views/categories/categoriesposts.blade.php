@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="pull-right">
        </div>
        <div class="row">

            <div class="col-md-8 col-md-offset-2">

                <div class="panel panel-default">
                    <div class="panel-heading text-center">Post View</div>

                    <div class="panel-body">
                        <div class="col-md-4">
                            <ul class="list-group">
                                @if(count($categories)>0)

                                    @foreach($categories as $category)
                                        <li class="list-group-item"> <a href='{{url("/category/{$category->id}")}}'>{{$category->category}}</a></li>
                                    @endforeach
                                @else
                                    <p>No Category Found Yet !</p>
                                @endif
                            </ul>

                        </div>
                        <div class="col-md-8 text-center">
                            @if(count($posts)>0)
                             @foreach($posts as $post)
                            <h4>{{$post->post_title}}</h4>
                            <img src="{{$post->post_image}}" style="align-content: center" >
                            <p>{{$post->post_body}}</p>
                            <cite style="float: left; font-family:Georgia, serif ">
                                Posted on:{{date('M j, Y H:i',strtotime($post->updated_at))}}
                            </cite>
                                <hr style="margin-top: 45px;">
                             @endforeach
                             @else
                                   <h4>No Posts Added yet into {{$categoryname}} Category</h4>
                             @endif


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
