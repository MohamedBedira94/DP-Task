
<!-- search box container starts  -->
<div class="search">
    <p>&nbsp;</p>
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
            <div class="input-group">
                <span class="input-group-addon" style="color: white; background-color: rgb(124,77,255);">Client SEARCH</span>
                <input type="text" autocomplete="off" id="search" class="form-control input-lg" placeholder="Enter Client Name Here">
            </div>
        </div>
    </div>
</div>
<!-- search box container ends  -->
<div id="txtHint" class="title-color" style="padding-top:50px; text-align:center;" ><b>Clients information will be listed here...</b></div>

</div>