<?php
if(!empty($clients ))
{
    $count = 1;
    $outputhead = '';
    $outputbody = '';
    $outputtail ='';

    $outputhead .= '
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created At</th>
                                <th>Options</th>
                            </tr>
                        </thead>
                        <tbody>
                ';

    foreach ($clients as $client)
    {

        $outputbody .=  '

                            <tr>
		                        <td>'.$count++.'</td>
		                        <td>'.$client->name.'</td>
		                        <td>'.$client->email.'</td>
		                        <td>'.$client->address.'</td>
		                        <td>'.$client->phone.'</td>
                            </tr>
                    ';

    }

    $outputtail .= '
                        </tbody>
                    </table>';

    echo $outputhead;
    echo $outputbody;
    echo $outputtail;
}

else
{
    echo 'Data Not Found';
}
?>