<div class="modal fade" id="create-item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">

    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>

                <h4 class="modal-title" id="myModalLabel">Create Client</h4>

            </div>

            <div class="modal-body">

                <form data-toggle="validator" action="{{ route('clients.store') }}" method="POST">

                    <div class="form-group">

                        <label class="control-label" for="title">Name:</label>

                        <input type="text" name="name" class="form-control" placeholder="Name" data-error="Please enter title." required />

                        <div class="help-block with-errors"></div>

                    </div>

                    <div class="form-group">

                        <label class="control-label" for="title">Email Address:</label>

                        <input type="email" name="email" class="form-control" placeholder="Email Address" data-error="Please enter email." required />

                        <div class="help-block with-errors"></div>

                    </div>

                    <div class="form-group">

                        <label class="control-label" for="title">Address:</label>

                        <input type="text" name="address" class="form-control" placeholder="Enter your address" data-error="Please enter address." required />

                        <div class="help-block with-errors"></div>

                    </div>

                    <div class="form-group">

                        <label class="control-label" for="title">Mobile/Phone:</label>

                        <input type="text" name="phone" class="form-control" placeholder="Enter your Mobile Number" data-error="Please enter address." required />

                        <div class="help-block with-errors"></div>

                    </div>
                    <div class="form-group">

                        <button type="submit" class="btn crud-submit btn-success">Submit</button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>