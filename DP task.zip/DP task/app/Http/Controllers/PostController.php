<?php

namespace App\Http\Controllers;

use App\Category;
use App\Comment;
use App\DisLike;
use App\Like;
use App\Post;
use App\Profile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;

use Auth;
use Illuminate\Http\Request;

class PostController extends Controller
{
   public function post(){
       $categories=Category::all();
       $posts=Post::all();
       //return $categories;
       //return $posts;
       return view('posts.post',compact('categories','posts'));
   }
    public function addPost(Request $request)
    {
        $this->validate($request, [
            'post_title' => 'required',
            'post_body' => 'required',
            'category_id' => 'required',
            'post_image' => 'required',
        ]);

        $post = new Post();
        $post->post_title = $request->input('post_title');
        $post->user_id = Auth::user()->id;
        $post->category_id = $request->input('category_id');
        $post->post_body = $request->input('post_body');
        if (Input::hasFile('post_image')) {
            $file = Input::file('post_image');
            $file->move(public_path() . '/posts/', $file->getClientOriginalName());
            $url = URL::to("/") . '/posts/' . $file->getClientOriginalName();
        }
        $post->post_image = $url;
        $post->save();

        return redirect('/home')->with('response', 'Post Added Successfully');
    }

    public function view($id){
        $post=Post::find($id);
        $likenum=Like::all()->where('post_id',$id)->count();
        $dislikenum=DisLike::all()->where('post_id',$id)->count();
         //return $dislikenum;
        //return $likenum;
        $categories =Category::all();
        $comments=DB::table('users')
            ->join('comments','users.id','=','comments.user_id')
            ->join('posts','comments.post_id','=','posts.id')
            ->select('users.name','comments.*')
            ->where(['posts.id' => $id])
            ->get();

        //return $comments;
        return view('posts.view',compact('post','categories','comments','likenum','dislikenum'));
    }

    public function edit($id){

        $post=Post::find($id);
        $category_post=Post::find($id)->category_id;
        $categories=Category::all();
        $category=Category::find($category_post);
       // return $category;
        return view('posts.edit',compact('post','categories','category'));
    }


    public function editPost(Request $request,$id){

        $this->validate($request, [
            'post_title' => 'required',
            'post_body' => 'required',
            'category_id' => 'required',
            'post_image' => 'required',
        ]);

        $post = new Post();
        $post->post_title = $request->input('post_title');
        $post->user_id = Auth::user()->id;
        $post->category_id = $request->input('category_id');
        $post->post_body = $request->input('post_body');
        if (Input::hasFile('post_image')) {
            $file = Input::file('post_image');
            $file->move(public_path() . '/posts/', $file->getClientOriginalName());
            $url = URL::to("/") . '/posts/' . $file->getClientOriginalName();
        }

        $post->post_image = $url;
        $data=array(
           'post_title'=> $post->post_title,
            'post_body'=> $post->post_body,
            'category_id'=> $post->category_id,
            'post_image'=> $post->post_image,
            'user_id' =>$post->user_id,
        );
        Post::where('id',$id)->update($data);
        $post->update();
                return redirect('/home')->with('response', 'Post Updated Successfully');

    }

    public function deletePost($id){

        Post::where('id',$id)->delete();
        return redirect('/home')->with('response','Post Deleted Successfully');
    }

    public function category($cat_id){
        $categories=Category::all();
        $posts=Post::all()->where('category_id',$cat_id);
        $categoryname=Category::find($cat_id)->category;
        /*return $posts;
        exit();*/
        return view('categories.categoriesposts',compact('categories','posts','categoryname'));
    }

    public function comment(Request $request,$post_id){

        $this->validate($request,[
            'comment' => 'required',
        ]);
        $comment = new Comment;
        $comment->user_id = Auth::user()->id;
        $comment->post_id = $post_id;
        $comment->comment= $request->input('comment');
        $comment->save();

        return redirect("/view/{$post_id}")->with('response','Comment Added Successfully');

    }

    public function like($id){
        $login_user=Auth::user()->id;
        $like_user=Like::where(['user_id'=>$login_user,'post_id'=>$id])->first();
        if(empty($like_user->user_id)){
            $user_id=Auth::user()->id;
            $email=Auth::user()->email;
            $like = new Like;
            $like->user_id=$user_id;
            $like->post_id=$id;
            $like->email=$email;
            $like->save();

            return redirect("/view/{$id}");
        }else{
            return redirect("/view/{$id}");
        }


    }

    public function dislike($id){

        $login_user=Auth::user()->id;
        $dislike_user=DisLike::where(['user_id'=>$login_user,'post_id'=>$id])->first();
        if(empty($dislike_user->user_id)){
            $user_id=Auth::user()->id;
            $email=Auth::user()->email;
            $post_id=$id;
            $dislike = new DisLike;
            $dislike->user_id=$user_id;
            $dislike->post_id=$id;
            $dislike->email=$email;
            $dislike->save();

            return redirect("/view/{$id}");
        }else{
            return redirect("/view/{$id}");
        }


    }

    public function search(Request $request){

        $user_id=Auth::user()->id;
        $profile=Profile::find($user_id);
        //return $profiles;
        $search_keyword=$request->input('search');
        $posts=Post::where('post_title','LIKE','%'.$search_keyword.'%')->get();
        return view('posts.searchposts',compact('posts','profile'));

    }

}
