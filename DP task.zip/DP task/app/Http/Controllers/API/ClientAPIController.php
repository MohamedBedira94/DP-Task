<?php
namespace App\Http\Controllers\API;


use App\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ClientAPIController extends APIBaseController {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    //using Advanced REST client (ARC) or Postman to display response
    // url : http://localhost:8000/api/clients

    public function myClients(){

        return view('clients.my-clients');
    }

    public function liveSearch(Request $request)
    {
        $search = $request->id;

        if (is_null($search))
        {
            return view('clients.livesearch');
        }
        else
        {
            $clients= Client::where('name','LIKE',"%{$search}%")
                ->get();

            return view('clients.livesearchajax',compact('clients'));
        }
    }

    public function index()
    {
        $clients = Client::latest()->paginate(5);

       return response()->json($clients);
       // return $this->sendResponse($clients->toArray(), 'Clients retrieved successfully.');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();


        $validator = Validator::make($input, [
            'name' => 'required',
            'email' => 'required',
            'address' => 'required',
            'phone' => 'required',
        ]);


        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }


        $client = Client::create($input);

        return response()->json($client);

       // return $this->sendResponse($client->toArray(), 'Client created successfully.');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $client = Client::find($id);


        if (is_null($client)) {
            return $this->sendError('Client not found.');
        }

        return response()->json($client);
        //return $this->sendResponse($client->toArray(), 'Client retrieved successfully.');
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = $request->all();


        $validator = Validator::make($input, [
            'name' => 'required',
            'email' => 'required',
            'address' => 'required',
            'phone' => 'required',
        ]);


        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }


        $client = Client::find($id);
        if (is_null($client)) {
            return $this->sendError('Client not found.');
        }


        $client->name = $input['name'];
        $client->email = $input['email'];
        $client->address = $input['address'];
        $client->phone = $input['phone'];
        $client->save();

        return response()->json($client);
        //return $this->sendResponse($client->toArray(), 'Client updated successfully.');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $client = Client::find($id);


        if (is_null($client)) {
            return $this->sendError('Client not found.');
        }


        $client->delete();

        return response()->json(['done!']);
        //return $this->sendResponse($id, 'Client deleted successfully.');
    }
}