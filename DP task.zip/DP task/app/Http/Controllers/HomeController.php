<?php

namespace App\Http\Controllers;

use App\Post;
use App\Profile;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $auth_id= Auth::user()->id;

        $profiles=Profile::all()->where('user_id',$auth_id);

       // return $profile;
        //$posts=Post::all();
        $posts=Post::paginate(5);
        return view('home',compact('profiles','posts'));
    }

}
