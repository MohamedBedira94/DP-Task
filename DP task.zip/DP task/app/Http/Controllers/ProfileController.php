<?php

namespace App\Http\Controllers;

use App\Profile;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;

class ProfileController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function profile(){
        return view('profiles.profile');
    }

    public function addProfile(Request $request){

        $this->validate($request,[
            'name' => 'required',
            'designation' => 'required',
            'profile' => 'required',
        ]);

        $profile = new Profile;
        $profile->name=$request->input('name');
        $profile->user_id=Auth::user()->id;
        $profile->designation=$request->input('designation');
        if(Input::hasFile('profile')) {
            $file = Input::file('profile');
            $file->move(public_path() . '/uploads/', $file->getClientOriginalName());
            $url = URL::to("/") . '/uploads/' . $file->getClientOriginalName();
        }
        $profile->profile=$url;
        $profile->save();

      return redirect('/home')->with('response','Profile Added Successfully');

    }
}
