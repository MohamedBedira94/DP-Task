<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = [
        'id','user_id', 'post_title', 'post_body','category_id','post_image',
    ];

    public function user(){
        return $this->belongsTo('App\User','user_id');
    }
    public function comment(){
        return $this->hasMany('App\Comment');
    }
}
