<?php

namespace App;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens,Notifiable;

    //using passport package for Authentication Api in login and register

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','gender','hobbies',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

     // Relation between user Model and VerifyUser one-to-one each user has only only and unique one verfication code
    public function verifyUser()
    {
        return $this->hasOne('App\VerifyUser');
    }
    //user has only one profile
    public function profile()
    {
        return $this->hasOne('App\Profile');
    }

    //user may be has one or more comments
    public function comment(){
        return $this->hasMany('App\Comment');
    }

   // user may be has one or more comments
    public function tasks()
    {
        return $this->hasMany('App\Task');
    }

}
