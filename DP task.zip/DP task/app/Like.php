<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Like extends Model
{
    protected $fillable = [
        'id', 'user_id', 'post_id','email',
    ];

    public function user(){
        return $this->belongsTo('App\User','user_id');
    }
    public function post(){
        return $this->belongsTo('App\Post','post_id');
    }
}
