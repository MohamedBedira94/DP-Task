<!DOCTYPE html>

<html>

<head>

    <title>Clients</title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css">

</head>

<body>

<div class="container ">

    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2 style="margin: 30px;">Clients Management</h2>

            </div>

            <div class="pull-right">

                <a  class="btn btn-danger" href='<?php echo e(url("/home")); ?>' style="margin-top: 40px;">Back</a>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#create-item" style="margin-top: 40px;">Create New Client</button>

            </div>

        </div>

        <?php echo $__env->make('clients.livesearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <table class="table table-bordered">

        <thead>

        <tr>
            <th>No</th>
            <th>Name</th>

            <th>Email</th>

            <th>Address</th>

            <th>Phone</th>

            <th width="200px">Action</th>

        </tr>

        </thead>

        <tbody>

        </tbody>

    </table>



    <ul id="pagination" class="pagination-sm"></ul>



    <!-- Create Item Modal -->

    <?php echo $__env->make('clients.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Edit Item Modal -->

    <?php echo $__env->make('clients.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>

<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

<script>

    $.ajaxSetup({

        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        }

    });

    $(document).ready(function(){
        $("#search").keyup(function(){
            var str=  $("#search").val();
            if(str == "") {
                $( "#txtHint" ).html("<b>Clients information will be listed here...</b>");
            }else {
                $.get( "<?php echo e(url('api/my-clients/livesearch?id=')); ?>"+str, function( data ) {
                    $( "#txtHint" ).html( data );
                });
            }
        });
    });
</script>

<script type="text/javascript">

    var url = "<?php echo route('clients.index')?>";

</script>

<script src="../js/clients-ajax.js"></script>



</body>

</html>