<style>
    .avatar{
        border-radius: 100%;
        max-width: 100px;
        max-height: 135px;
    }
    .modify{
        text-align: center;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="pull-right">
            
        </div>
        <div class="row">

            <div class="col-md-8 col-md-offset-2">

                <?php if(session('response')): ?>
                    <div class="alert alert-success"><?php echo e(session('response')); ?></div>
                <?php endif; ?>
                <div class="panel panel-default">
                    <div class="panel-heading">

                        <div class="row">
                            <div class="col-md-4">Dashboard</div>
                            <div class="col-md-8">
                                <form method="POST" action='<?php echo e(url("/search")); ?>'>
                                    <?php echo e(csrf_field()); ?>

                                    <div class="input-group">

                                        <input type="text" name="search" class="form-control" placeholder="Search for..."/>
                                    <span class="input-group-btn">
                                        <button type="submit" class="btn btn-default">
                                            GO!
                                        </button>
                                    </span>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="panel-body">
                        <div class="col-md-4">

                            <?php if(!empty($profile)): ?>

                                    <img src="<?php echo e(url($profile->profile)); ?>" alt="" class="avatar" >
                                    <p class="lead"><?php echo e($profile->name); ?></p>
                                    <p class="lead"><?php echo e($profile->designation); ?></p>

                            <?php else: ?>
                                
                            <?php endif; ?>

                        </div>
                        <div class="col-md-8 modify">
                            <?php if(count($posts)>0): ?>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($post->post_title); ?></h4>
                                    <img src="<?php echo e($post->post_image); ?>" style="align-content: center; width: 256px; height: 256px;"  >
                                    <p><?php echo e(substr($post->post_body,0,150)); ?></p>
                                    <ul class="nav nav-pills">
                                        <li role="presentation">
                                            <a href='<?php echo e(url("/view/{$post->id}")); ?>'>
                                                <span class="fa fa-eye" aria-hidden="true">View</span>
                                            </a>
                                        </li>
                                        <?php if(Auth::user()->id==1): ?>
                                        <li role="presentation">
                                            <a href='<?php echo e(url("/edit/{$post->id}")); ?>'>
                                                <span class="fa fa-pencil-square-o" aria-hidden="true">Edit</span>
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a href='<?php echo e(url("/delete/{$post->id}")); ?>'>
                                                <span class="fa fa-trash-o" aria-hidden="true">Delete</span>
                                            </a>
                                        </li>
                                            <?php endif; ?>
                                    </ul>
                                    <cite style="float: left; font-family:Georgia, serif ">
                                        Posted on:<?php echo e(date('M j, Y H:i',strtotime($post->updated_at))); ?>

                                    </cite>


                                    <hr style="margin-top: 45px;">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No Posts Available Yet</p>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>