<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="pull-right">
        </div>
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <?php if(session('response')): ?>
                    <div class="alert alert-success"><?php echo e(session('response')); ?></div>
                <?php endif; ?>

                <div class="panel panel-default">
                    <div class="panel-heading text-center">Post View</div>

                    <div class="panel-body">
                        <div class="col-md-4">
                         <ul class="list-group">
                             <?php if(count($categories)>0): ?>

                                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li class="list-group-item"> <a href='<?php echo e(url("/category/{$category->id}")); ?>'><?php echo e($category->category); ?></a></li>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php else: ?>
                                 <p>No Category Found Yet !</p>
                             <?php endif; ?>
                         </ul>

                        </div>
                        <div class="col-md-8 text-center">

                                    <h4><?php echo e($post->post_title); ?></h4>
                                    <img src="<?php echo e($post->post_image); ?>" style="align-content: center" >
                                    <p><?php echo e($post->post_body); ?></p>
                                    <ul class="nav nav-pills">
                                        <?php $i = 0; ?>
                                        <li role="presentation">
                                            
                                            <a href='<?php echo e(url("/like/{$post->id}")); ?>'>
                                                <span class="fa fa-thumbs-o-up" aria-hidden="true">
                                                   Like (<?php echo e(!empty($likenum)?$likenum:null); ?>)</span>
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            
                                            <a href='<?php echo e(url("/dislike/{$post->id}")); ?>'>
                                           <span class="fa fa-thumbs-o-down" aria-hidden="true">disLike (<?php echo e(!empty($dislikenum)?$dislikenum:null); ?>)</span>

                                            </a>

                                        </li>

                                        <li role="presentation">
                                            <a href='<?php echo e(url("/comment/{$post->id}")); ?>'>
                                                <span class="fa fa-comment-o" aria-hidden="true">Comment</span>
                                            </a>
                                        </li>
                                    </ul>
                            <form method="post" action='<?php echo e(url("/comment/{$post->id}")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <textarea id="comment" class="form-control" name="comment" rows="6" required autofocus>

                                    </textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-lg btn-block">Add Comment</button>
                                </div>
                            </form>

                            <h3>Comments</h3>

                            <?php if(count($comments)>0): ?>

                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($comment->comment); ?></p>
                                    <p>Posted By: <?php echo e(\App\User::find($comment->user_id)->name); ?></p>
                                    <hr/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No Comments Added Yet</p>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>