<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="pull-right">
            
        </div>
        <div class="row">

            <div class="col-md-8 col-md-offset-2">

                    <div class="panel panel-default">
                        <div class="panel-heading">Profile</div>
                    <?php if(count($errors)>0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(url('/addProfile')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">Enter Name</label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required >

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('designation') ? ' has-error' : ''); ?>">
                                <label for="designation" class="col-md-4 control-label">Job</label>

                                <div class="col-md-6">
                                    <input id="designation" type="text" class="form-control" name="designation" required>

                                    <?php if($errors->has('designation')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('designation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('profile') ? ' has-error' : ''); ?>">
                                <label for="profile" class="col-md-4 control-label">Profile</label>

                                <div class="col-md-6">
                                    <input id="profile" type="file" class="form-control" name="profile" value="<?php echo e(old('profile')); ?>" required >

                                    <?php if($errors->has('profile')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('profile')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        Add Profile
                                    </button>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>