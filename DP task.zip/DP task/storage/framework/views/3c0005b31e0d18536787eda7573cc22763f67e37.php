<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Upload User Image Profile</div>
                </div>
                <?php echo Form::open(array('route' => 'profiles.store','method'=>'POST' )); ?>


                    <?php echo e(Form::hidden('user_id', Auth::user()->id)); ?>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-horizontal">
                            <strong>Choose User Profile</strong>
                            <?php echo Form::file('image', null, array('placeholder' => 'Image','class' => 'form-control')); ?>

                        </div>
                    </div>



                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                        <button type="submit" class="btn btn-primary ">Submit</button>
                    </div>





                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>