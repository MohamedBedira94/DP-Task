-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 30, 2018 at 02:49 PM
-- Server version: 5.7.17-log
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bright_creation`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `created_at`, `updated_at`) VALUES
(1, 'Sports', '2018-03-24 19:31:42', '2018-03-24 19:31:42'),
(2, 'Entertainment', '2018-03-24 19:31:51', '2018-03-24 19:31:51'),
(3, 'Healthy', '2018-03-24 19:31:58', '2018-03-24 19:31:58'),
(4, 'Politics', '2018-03-24 19:32:08', '2018-03-24 19:32:08'),
(5, 'Travel', '2018-03-24 19:32:15', '2018-03-24 19:32:15'),
(6, 'Economy', '2018-03-24 19:32:24', '2018-03-24 19:32:24'),
(7, 'Programming', '2018-03-24 21:08:18', '2018-03-24 21:08:18'),
(8, 'Movies', '2018-03-25 13:18:46', '2018-03-25 13:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `address`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'Ali Ibrahim', 'Alex', 'ali@gmail.com', '01273734627', NULL, NULL),
(2, 'Mohamed Mostafa', 'Giza', 'mohamed@gmail.com', '01097741951', NULL, '2018-03-27 21:06:39'),
(4, 'Ibrahim Mohmed', 'Sohag', 'ibrahim@gmail.com', '01168546658', '2018-03-27 20:23:48', '2018-03-27 20:23:48'),
(5, 'Abdelrahman Elsayed', 'Shibian', 'abdelrahman@yahoo.com', '01568946719', '2018-03-27 21:09:40', '2018-03-27 21:09:40'),
(6, 'Emad Maher', '6 October', 'emad@gmail.com', '01297634967', '2018-03-27 21:12:23', '2018-03-27 21:12:23'),
(8, 'Noura Momen', 'Minia', 'noura@gmail.com', '01106795483', '2018-03-27 21:13:54', '2018-03-27 21:13:54');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `post_id`, `comment`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'wordpress is large CMS with easy Feature', '2018-03-25 17:51:26', '2018-03-25 17:51:26'),
(2, 1, 6, 'Last Survior is the best Top 10 film.', '2018-03-25 17:55:06', '2018-03-25 17:55:06'),
(3, 5, 1, 'Wordpress most used CMS in last 4 years', '2018-03-25 21:25:15', '2018-03-25 21:25:15');

-- --------------------------------------------------------

--
-- Table structure for table `dislikes`
--

CREATE TABLE `dislikes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dislikes`
--

INSERT INTO `dislikes` (`id`, `user_id`, `post_id`, `email`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 'menna_ahmed@gmail.com', '2018-03-25 22:59:52', '2018-03-25 22:59:52'),
(2, 6, 2, 'mostafa@yhaoo.com', '2018-03-25 23:09:48', '2018-03-25 23:09:48');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `contact_number`, `position`, `created_at`, `updated_at`) VALUES
(1, 'hhghhgh', 'mostafa@yhaoo.com', '0159779656512', 'Senior', '2018-03-29 04:13:48', '2018-03-29 04:13:48'),
(2, 'acac', 'ceo@arabia2web.com', '455455454', 'sscscs', '2018-04-11 16:07:51', '2018-04-11 16:07:51');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `user_id`, `post_id`, `email`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 'menna_ahmed@gmail.com', '2018-03-25 22:59:58', '2018-03-25 22:59:58'),
(2, 1, 1, 'mohamed.bedera@gmail.com', '2018-03-25 23:00:34', '2018-03-25 23:00:34'),
(3, 4, 1, 'admin@admin.com', '2018-03-25 23:01:23', '2018-03-25 23:01:23'),
(4, 1, 5, 'mohamed.bedera@gmail.com', '2018-03-27 16:20:35', '2018-03-27 16:20:35'),
(5, 9, 5, 'hoassam_nader@gmail.com', '2018-03-27 23:31:29', '2018-03-27 23:31:29');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_03_22_204916_create_verify_users_table', 1),
(4, '2018_03_24_144405_create_profiles_table', 1),
(5, '2018_03_24_144559_create_categories_table', 1),
(6, '2018_03_24_212632_create_posts_table', 2),
(7, '2018_03_24_212832_create_comments_table', 3),
(8, '2018_03_25_234943_create_likes_table', 4),
(9, '2018_03_25_235505_create_dislikes_table', 5),
(10, '2016_06_01_000001_create_oauth_auth_codes_table', 6),
(11, '2016_06_01_000002_create_oauth_access_tokens_table', 6),
(12, '2016_06_01_000003_create_oauth_refresh_tokens_table', 6),
(13, '2016_06_01_000004_create_oauth_clients_table', 6),
(14, '2016_06_01_000005_create_oauth_personal_access_clients_table', 6),
(15, '2018_03_27_072414_create_clients_table', 7),
(16, '2018_03_28_024740_create_products_table', 8),
(17, '2018_03_29_033337_create_tasks_table', 9),
(18, '2018_03_29_052010_create_employees_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('30c76178d208df509c8f1c327061f70fc06ed7a30f0b70ab71e2efe66dcc819df92464c69d156bc2', 1, 3, 'MyApp', '[]', 0, '2018-03-27 04:57:47', '2018-03-27 04:57:47', '2019-03-27 06:57:47'),
('353206cd6908b1afb7a2580345204bae5753514a5f57227fa6677cc9893c5940f74922fa27df2f65', 1, 3, 'MyApp', '[]', 0, '2018-03-27 15:01:33', '2018-03-27 15:01:33', '2019-03-27 17:01:33'),
('43208a298c47cf55b892a9d7b194de9408aaf3f506f0b2bc345d5cf7e916ed2f89e25194ff633b61', 1, 3, 'MyApp', '[]', 0, '2018-03-27 16:12:36', '2018-03-27 16:12:36', '2019-03-27 18:12:36'),
('f1415123ba2196cf9550e06f10d20b0b0a7a7a56651b50a842b4769bc7f25f73e6fae4e8453ab62b', 1, 3, 'MyApp', '[]', 0, '2018-03-27 06:54:52', '2018-03-27 06:54:52', '2019-03-27 08:54:52'),
('fc52b9379cb682bf74c0e16a0a1d65d1fff2ee1646bf319a95525301c5c5759452ae42a835127872', 1, 3, 'MyApp', '[]', 0, '2018-03-27 06:03:38', '2018-03-27 06:03:38', '2019-03-27 08:03:38');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'FHAFhFkRXqsxK9qRyUOp1MF5IOpuRID2Es60vqOf', 'http://localhost', 1, 0, 0, '2018-03-27 04:00:55', '2018-03-27 04:00:55'),
(2, NULL, 'Laravel Password Grant Client', '36nLe43xKn7r0JF4DblBZdJGHrgHwdpUgFcdwCsr', 'http://localhost', 0, 1, 0, '2018-03-27 04:00:55', '2018-03-27 04:00:55'),
(3, NULL, 'Laravel Personal Access Client', 'CMnN0Utj0CNdnPFnFGq1Unns9oXP0KEiw9jmqpMk', 'http://localhost', 1, 0, 0, '2018-03-27 04:01:35', '2018-03-27 04:01:35'),
(4, NULL, 'Laravel Password Grant Client', '2Aj9qGjnL3Y8lisZkzv7MNYMC8bbmYqmRrnTFXft', 'http://localhost', 0, 1, 0, '2018-03-27 04:01:35', '2018-03-27 04:01:35');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2018-03-27 04:00:55', '2018-03-27 04:00:55'),
(2, 3, '2018-03-27 04:01:35', '2018-03-27 04:01:35');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `post_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `post_title`, `post_body`, `category_id`, `post_image`, `created_at`, `updated_at`) VALUES
(1, 1, 'Wordpress', 'WordPress is an open source Content Management System (CMS), which allows the users to build dynamic websites and blog. WordPress is the most popular blogging system on the web and allows updating, customizing and managing the website from its back-end CMS and components. This tutorial will teach you the basics of WordPress using which you can create websites with ease. The tutorial is divided into various sections for convenience. Each of these sections contain related topics with screenshots explaining the WordPress admin screens.', 2, 'http://127.0.0.1:8000/posts/if_wordpress_1632490.png', '2018-03-24 21:09:50', '2018-03-25 02:52:38'),
(2, 1, 'Codeigniter', 'CodeIgniter is an Application Development Framework - a toolkit - for people who build web sites using PHP. Its goal is to enable you to develop projects much faster than you could if you were writing code from scratch, by providing a rich set of libraries for commonly needed tasks, as well as a simple interface and logical structure to access these libraries. CodeIgniter lets you creatively focus on your project by minimizing the amount of code needed for a given task.', 7, 'http://127.0.0.1:8000/posts/if_codeigniter_1285072.png', '2018-03-24 21:12:53', '2018-03-24 21:12:53'),
(4, 1, 'Laravel', 'Laravel is a powerful MVC PHP framework, designed for developers who need a simple and elegant toolkit to create full-featured web applications. Laravel was created by Taylor Otwell. This is a brief tutorial that explains the basics of Laravel framework.', 7, 'http://127.0.0.1:8000/posts/if_laravel_1006880.png', '2018-03-25 13:17:11', '2018-03-25 13:17:11'),
(5, 1, 'Football', 'Cristiano Ronaldo\r\nGOIH, ComM\r\nRussia-Portugal CC2017 (11) (cropped).jpg\r\nRonaldo with Portugal in June 2017\r\nPersonal information\r\nFull name	Cristiano Ronaldo dos Santos Aveiro[1]\r\nDate of birth	5 February 1985 (age 33)[2]\r\nPlace of birth	Funchal, Madeira, Portugal\r\nHeight	1.87 m (6 ft 2 in)[3]\r\nPlaying position	Forward\r\nClub information\r\nCurrent team\r\nReal Madrid\r\nNumber	7\r\nYouth career\r\n1992–1995	Andorinha\r\n1995–1997	Nacional\r\n1997–2002	Sporting CP\r\nSenior career*\r\nYears	Team	Apps	(Gls)\r\n2002–2003	Sporting CP B	2	(0)\r\n2002–2003	Sporting CP	25	(3)\r\n2003–2009	Manchester United	196	(84)\r\n2009–	Real Madrid	288	(307)\r\nNational team‡\r\n2001	Portugal U15	9	(7)\r\n2001–2002	Portugal U17	7	(5)\r\n2003	Portugal U20	5	(1)\r\n2002–2003	Portugal U21	10	(3)\r\n2004	Portugal U23	3	(2)\r\n2003–	Portugal	148	(81)\r\nHonours[show]\r\n* Senior club appearances and goals counted for the domestic league only and correct as of 21:48, 18 March 2018 (UTC)\r\n‡ National team caps and goals correct as of 22:50, 23 March 2018 (UTC)\r\nA man in a red shirt sticks out his tongue.	This article is part of a series about\r\nCristiano Ronaldo\r\nPortuguese professional footballer\r\n\r\nInternational goals Career achievements Comparisons to Lionel Messi\r\nNamesakes\r\n\r\nCristiano Ronaldo Campus Futebol Cristiano Ronaldo International Airport Galaxy CR7 Museu CR7\r\nFilms\r\n\r\nCristiano Ronaldo: The World at His Feet Ronaldo\r\nv t e\r\nCristiano Ronaldo dos Santos Aveiro GOIH, ComM (European Portuguese: [kɾiʃˈtjɐnu ʁoˈnaɫdu]; born 5 February 1985) is a Portuguese professional footballer who plays as a forward for Spanish club Real Madrid and the Portugal national team. Often considered the best player in the world and regarded by many as the greatest of all time,[note 1] Ronaldo has five Ballon d\'Or awards,[note 2] the most for a European player and is tied for most all-time. He is the first player in history to win four European Golden Shoes. He has won 25 trophies in his career, including five league titles, four UEFA Champions League titles and one UEFA European Championship. A prolific goalscorer, Ronaldo holds the records for most official goals scored in the top five European leagues (391', 1, 'http://127.0.0.1:8000/posts/if_soccer_3_53260.png', '2018-03-25 13:23:13', '2018-03-25 13:31:33'),
(6, 1, 'Top 10 Movies', 'Christopher Nolan dispenses with the exposition in favor of immersive aesthetics with Dunkirk, a dramatic account of the WWII evacuation of Dunkirk, France\'s beaches in 1941. Fractured between three interwoven time frames and perspectives (land, sea and air), and shot almost entirely in 70mm IMAX—which stands as the ideal format in which to see this overwhelmingly experiential work—Nolan\'s wartime tale cares little for character detail or contextual background', 8, 'http://127.0.0.1:8000/posts/if_Movies_48956.png', '2018-03-25 13:35:10', '2018-03-25 13:35:10'),
(7, 1, 'Android (Mobile Application)', 'Android Building Image Filters like Instagram\r\nBY RAVI TAMADA  47 COMMENTS\r\nNowadays image filters are quite common in lot of android apps. Instagram is famous for its popular filters feature and probably the first app to introduce image filters to android world. There are lot of other image editing apps provides image filters and image editing features.\r\n\r\nIn this article we are going to learn how to build an image filters app like Instagram. We won’t be covering the exact filter development but we use existing image filters library.', 7, 'http://127.0.0.1:8000/posts/if_android_1220385.png', '2018-03-25 14:04:00', '2018-03-25 14:04:00'),
(8, 1, 'IOS (Mobile Application)', 'Writing tests isn’t glamorous, but since tests can keep your sparkling app from turning into a bug-ridden piece of junk, it sure is necessary. If you’re reading this iOS Unit Testing and UI Testing tutorial, you already know you should write tests for your code and UI, but you’re not sure how to test in Xcode.\r\nMaybe you already have a “working” app but no tests set up for it, and you want to be able to test any changes when you extend the app. Maybe you have some tests written, but aren’t sure whether they’re the right tests. Or maybe you’re working on your app now and want to test as you go.', 7, 'http://127.0.0.1:8000/posts/if_5315_-_Apple_1314162.png', '2018-03-26 00:21:54', '2018-03-26 00:21:54');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `name`, `designation`, `profile`, `created_at`, `updated_at`) VALUES
(1, 1, 'Mohamed Bedira', 'Developer', 'http://127.0.0.1:8000/uploads/25660124_1180217162112381_2209051272058249366_n.jpg', '2018-03-24 19:31:26', '2018-03-24 19:31:26'),
(12, 4, 'Ahmed', 'Designer', 'http://127.0.0.1:8000/uploads/25552388_1180216872112410_9088101498638708330_n.jpg', '2018-03-25 20:52:50', '2018-03-25 20:52:50'),
(13, 5, 'Menna Ahmed', 'SAP Consultant', 'http://127.0.0.1:8000/uploads/4_1199316512.jpg', '2018-03-25 21:24:02', '2018-03-25 21:24:02'),
(14, 6, 'Ahmed Mostafa', 'Executive Manager', 'http://127.0.0.1:8000/uploads/29-mr-robot.w750.h560.2x.jpg', '2018-03-25 23:05:42', '2018-03-25 23:05:42'),
(15, 7, 'Abdelrahman Omar', 'IOS Developer', 'http://127.0.0.1:8000/uploads/1235038_552377321464268_1295304560_n.jpg', '2018-03-25 23:30:57', '2018-03-25 23:30:57'),
(16, 8, 'Mona Mahmoud', 'Software Engineer', 'http://localhost:8000/uploads/1350824188858.jpg', '2018-03-27 04:26:00', '2018-03-27 04:26:00'),
(18, 9, 'Hossam Nader', 'DBA', 'http://localhost:8000/uploads/20638650_747360318785252_1811042004695147811_n.jpg', '2018-03-27 23:30:32', '2018-03-27 23:30:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hobbies` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `hobbies`, `verified`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mohamed Bedira', 'mohamed.bedera@gmail.com', '$2y$10$ZZJR0zlMeNRvVue6xYe8w.BOohEAF40OwnHrALi0G6ZiTOqJEa/Dm', 'male', 'Reading,Writing,Playing Football', 1, 'vteZDKZDFAnJ9oaAQW9xYkzeBEQ5vKxiv70saY0FJgcrhg5VQfFyfjq8ZZvj', '2018-03-24 19:29:52', '2018-03-24 19:30:33'),
(4, 'Admin', 'admin@admin.com', '$2y$10$uCrEwKovQgvrfq5swgvjpOCfv0.9CyEoG2A.7te9QHvTz6XNN/E9a', 'male', 'Watching Movies,Playing Football', 1, 'vm5isOYYwgTLnF06FHzikM7O34kXGr29W2jHcaUjOAnjH8XedZ9Vbpt7cabG', '2018-03-25 20:43:25', '2018-03-25 20:44:11'),
(5, 'Menna Ahmed', 'menna_ahmed@gmail.com', '$2y$10$HN.CPpfk8BKoIzEJ5KLlGeirPHpThKLT1RZPDFLnJE5UQ3Jj1TvSy', 'female', 'Reading,Writing,Watching Movies', 1, 'm6vHSjLAkzkxd4T5Xz2kQaUR2DjcIuJvuUXpK8SBFGyC5AA1YjWozISFj3h5', '2018-03-25 21:21:48', '2018-03-25 21:22:18'),
(6, 'Ahmed Mostafa', 'mostafa@yhaoo.com', '$2y$10$HiTr.mlDkq5G3nn9pNgsXOvNWnnjjRNdGiaOJiRSeBEHufnPkBSZK', 'male', 'Reading,Playing Football', 1, 'torxrkDqrCER9UQjONu6a3NhtVUwZQ3ZG63SwigkCrcJGUpIL5hGaRbiZsJx', '2018-03-25 23:03:39', '2018-03-25 23:04:16'),
(7, 'Abdelrahman', 'Abdo@gmail.com', '$2y$10$R5uTbVACmFjSqPWMOBPi...lm0DYknGwttQDOy3r5hJ8LNa5b7jTm', 'male', 'Reading,Writing,Playing Football', 1, 'NkTao3KUPCqP2KzUPCdOQ7iLJl5KybeJ9ve2zkqHyXuTbdZymdz5bnzjSDJu', '2018-03-25 23:10:45', '2018-03-25 23:11:10'),
(8, 'Mona Mahmoud', 'mona@gmail.com', '$2y$10$HIMQsVSQ5GanxluEyQrfoezEYT90PHGNAz5c35EsNcfFBFf3ysUYe', 'female', 'Writing,Watching Movies', 1, 'MsH4IQEkDd5Hpkvp5hnXdccsqw0B7BZ3cYNTEpNqVZjLmKjSLgTlnLaGksAc', '2018-03-27 04:18:20', '2018-03-27 04:21:38'),
(9, 'Hossam Nader', 'hoassam_nader@gmail.com', '$2y$10$yyHWUDj1mL5RLgcH5xovLuV/.UUzzY0CilmE34.LCQ37fsUKbrUeO', 'male', 'Reading,Writing,Playing Football', 1, 'W6BGpVt5F7fGqQTyEG1q8hCfYsYZHxx1xd7maek69jvQJ6krZflqqoZiX9Xv', '2018-03-27 23:16:11', '2018-03-27 23:18:21');

-- --------------------------------------------------------

--
-- Table structure for table `verify_users`
--

CREATE TABLE `verify_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verify_users`
--

INSERT INTO `verify_users` (`user_id`, `token`, `created_at`, `updated_at`) VALUES
(1, '3cOYTpFvkFXnjszYlsyC9NvHYRhEctcEjuliMHWX', '2018-03-24 19:29:52', '2018-03-24 19:29:52'),
(4, 'tO21LtnnMSoZF1Hcx0wtFfrEaVaL41BnUKAxP9Sc', '2018-03-25 20:43:25', '2018-03-25 20:43:25'),
(5, 'rketBKfvM0UpbLWVeV5yz9qeHfyPOnmgiywZzulX', '2018-03-25 21:21:48', '2018-03-25 21:21:48'),
(6, 'q2WH3SHKr1SREFxA73HSgb9IqzbQEdD3sZ0Et88r', '2018-03-25 23:03:39', '2018-03-25 23:03:39'),
(7, 'Db9n0fcKbkP025dH9cYrGBSa0vnOhRVX6SEopG2k', '2018-03-25 23:10:45', '2018-03-25 23:10:45'),
(8, 'L30HAk8O31SyNYv3AiA7Cyn9qAiZRNSUL3l1256n', '2018-03-27 04:18:20', '2018-03-27 04:18:20'),
(9, 'dohMD5g5o6UhpwvDIuN5cvnGKe42NDN4XQVn2zHG', '2018-03-27 23:16:11', '2018-03-27 23:16:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_post_id_foreign` (`post_id`);

--
-- Indexes for table `dislikes`
--
ALTER TABLE `dislikes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dislikes_user_id_foreign` (`user_id`),
  ADD KEY `dislikes_post_id_foreign` (`post_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employees_name_unique` (`name`),
  ADD UNIQUE KEY `employees_email_unique` (`email`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `likes_user_id_foreign` (`user_id`),
  ADD KEY `likes_post_id_foreign` (`post_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_user_id_foreign` (`user_id`),
  ADD KEY `posts_category_id_foreign` (`category_id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profiles_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `verify_users`
--
ALTER TABLE `verify_users`
  ADD KEY `verify_users_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `dislikes`
--
ALTER TABLE `dislikes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dislikes`
--
ALTER TABLE `dislikes`
  ADD CONSTRAINT `dislikes_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `dislikes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `verify_users`
--
ALTER TABLE `verify_users`
  ADD CONSTRAINT `verify_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
